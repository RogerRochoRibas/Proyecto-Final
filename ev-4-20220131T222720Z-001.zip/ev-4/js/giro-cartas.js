
    var card1 = document.querySelector('.card1');
card1.addEventListener( 'mouseover', function() {
  card1.classList.toggle('is-flipped');
});

var card2 = document.querySelector('.card2');
    card2.addEventListener( 'mouseover', function() {
      card2.classList.toggle('is-flipped');
});

var card3 = document.querySelector('.card3');
    card3.addEventListener( 'mouseover', function() {
    card3.classList.toggle('is-flipped');
});

var card4 = document.querySelector('.card4');
    card4.addEventListener( 'mouseover', function() {
      card4.classList.toggle('is-flipped');
    });
    
var card5 = document.querySelector('.card5');
card5.addEventListener( 'mouseover', function() {
  card5.classList.toggle('is-flipped');
});

var card6 = document.querySelector('.card6');
    card6.addEventListener( 'mouseover', function() {
      card6.classList.toggle('is-flipped');
    });
    
var card7 = document.querySelector('.card7');
card7.addEventListener( 'mouseover', function() {
  card7.classList.toggle('is-flipped');
});

var card8 = document.querySelector('.card8');
    card8.addEventListener( 'mouseover', function() {
      card8.classList.toggle('is-flipped');
    });
    
var card9 = document.querySelector('.card9');
card9.addEventListener( 'mouseover', function() {
  card9.classList.toggle('is-flipped');
});  

var card10 = document.querySelector('.card10');
card10.addEventListener( 'mouseover', function() {
  card10.classList.toggle('is-flipped');
});

var card11 = document.querySelector('.card11');
card11.addEventListener( 'mouseover', function() {
  card11.classList.toggle('is-flipped');
});